# QueriKornerOpenApi30.Search

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**searchTags** | **[String]** |  | [optional] 
**searchSort** | **String** |  | [optional] 
**searchResults** | **[String]** |  | [optional] 
**numberOfSearchResults** | **Number** |  | [optional] 
