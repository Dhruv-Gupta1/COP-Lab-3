# QueriKornerOpenApi30.Tag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tagId** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**numberOfQuestions** | **Number** |  | [optional] 
**description** | **String** |  | [optional] 
