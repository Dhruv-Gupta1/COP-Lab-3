# QueriKornerOpenApi30.Question

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**questionId** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**body** | **String** |  | [optional] 
**tags** | **[String]** |  | [optional] 
**votes** | **Number** |  | [optional] 
**answerIds** | **[String]** |  | [optional] 
**numberOfAnswers** | **Number** |  | [optional] 
**createdAt** | **String** |  | [optional] 
**accepted** | **Boolean** |  | [optional] 
**createdBy** | **String** |  | [optional] 
