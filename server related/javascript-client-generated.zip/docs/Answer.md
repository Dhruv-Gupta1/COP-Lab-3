# QueriKornerOpenApi30.Answer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answerId** | **String** |  | [optional] 
**body** | **String** |  | [optional] 
**votes** | **Number** |  | [optional] 
**questionId** | **String** |  | [optional] 
**createdBy** | **String** |  | [optional] 
**createdAt** | **String** |  | [optional] 
