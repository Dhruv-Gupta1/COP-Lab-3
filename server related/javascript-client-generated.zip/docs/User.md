# QueriKornerOpenApi30.User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **String** |  | [optional] 
**username** | **String** |  | [optional] 
**password** | **String** |  | [optional] 
**rating** | **Number** |  | [optional] 
**questionsAsked** | **[String]** |  | [optional] 
**numberOfQuestionsAsked** | **Number** |  | [optional] 
**answersGiven** | **[String]** |  | [optional] 
**numberOfAnswersGiven** | **Number** |  | [optional] 
**profilePicture** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
